import React from "react";
import Cell from "./Cell";

export default class GridData extends React.Component {
  constructor(props) {
    super();
    this.state = {
      row: null,
      selectedRows: [],
    };
    this.getData = this.getData.bind(this);
    this.selectionTd = this.selectionTd.bind(this);
    this.getClasseName = this.getClasseName.bind(this);
  }


  getClasseName(row){
    var isRowSelected = this.state.selectedRows.some((rw) => {
      return JSON.stringify(rw) === JSON.stringify(row);
    });

    if (isRowSelected) return "rselected"
    return ""
  
  }

  selectRowEventHandler(row) {
    var selectedRows = this.props.onRowSelected(row);
    if (selectedRows !== undefined) {
       this.setState({selectedRows : selectedRows})

    }
     
  }

  selectionTd(row) {
    if (this.props.selection) {
      return (
        <td>
          <input
            type="checkbox"
            onChange={() => {
              this.selectRowEventHandler(row);
            }}
          />
        </td>
      );
    }

    return null;
  }

  getData() {
    return this.props.data.map((row, index) => {
      var columnsWithdata = this.props.columns.filter((col) => {
        return col.colspan === 1;
      });

      return (
        <tr key={index} className={this.getClasseName(row)}>
          {this.selectionTd(row)}
          <td className="sharp" key={index}>
            {index + 1}
          </td>

          {columnsWithdata.map((col, index2) => {
            return <Cell col={col} row={row} key={index2} />;
          })}
        </tr>
      );
    });
  }

  render() {
    return <tbody>{this.getData()}</tbody>;
  }
}
