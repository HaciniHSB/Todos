import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faSort,
  faSortUp,
  faSortDown,
} from "@fortawesome/free-solid-svg-icons";

export default class Hesderux extends React.Component {
  constructor(props) {
    super();
    this.onClickEventHandler = this.onClickEventHandler.bind(this);
    this.getNextDirection = this.getNextDirection.bind(this);
  }
  


  getSortIcon() {
    if (this.props.sorting){
      switch (this.props.sortingDirection) {
        case "ascending":
          return <FontAwesomeIcon className="filterIcon" icon={faSortUp} />;
        case "descending":
          return <FontAwesomeIcon className="filterIcon" icon={faSortDown} />;
        default:
          return <FontAwesomeIcon className="filterIcon" icon={faSort} />;
      }
    }
  }

  onClickEventHandler() {
    if (this.props.sorting){
      var nextDirection = this.getNextDirection();
      this.props.onSort(this.props.name, nextDirection);
      this.props.setDirection(this.props.name, nextDirection);
    }
  }

  getNextDirection() {
    switch (this.props.sortingDirection) {
      case "default":
        return "ascending";
      case "ascending":
        return "descending";
      case "descending":
        return "ascending";
      default:
        return "default";
    }
  }

  render() {
    return (
      <th
        className={this.props.classname}
        name={this.props.name}
        colSpan={this.props.colspan}
        rowSpan={this.props.rowspan}
        onClick={this.onClickEventHandler}
      >
        {this.props.title} {this.getSortIcon()}
      </th>
    );
  }
}
