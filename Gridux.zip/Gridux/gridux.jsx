﻿import React from "react";
import Headers from "./Headers";
import "./gridux.css";
import GridData from "./GridData";
import GridFilter from "./GridFilter";
import { dataSortTool, dataFilterTool, getDataType } from "./Tools";

export default class Gridux extends React.Component {
  constructor(props) {
    super();
    this.state = {
      data: props.data,
      selectedRows : []
    };
    this.setDefaultValuesToProps = this.setDefaultValuesToProps.bind(this);
    this.getHeaders = this.getHeaders.bind(this);
    this.getData = this.getData.bind(this);
    this.checkData = this.checkData.bind(this);
    this.getGridFilter = this.getGridFilter.bind(this);
    this.dataFilter = this.dataFilter.bind(this);
    this.dataSotring = this.dataSotring.bind(this);
    this.onRowSelectedEventHandler = this.onRowSelectedEventHandler.bind(this)
  }

  getSnapshotBeforeUpdate(prevProps,prevState){
    if(prevProps.data !== this.props.data){
      return true
    } 
    return false
  }

  componentDidUpdate(prevProps,prevState,snapShot){
    if(snapShot){
      this.setState({data : this.props.data})
    }
  }

  setDefaultValuesToProps(columns, data) {
    if (data === undefined) {
      throw new Error("Gridux properties data required");
    }
    const formatedColumns = columns.map((col) => {
      this.checkData(col);
      var filter = true;
      var sort = true;
      if (col.colspan > 1 || col.filtring === false) filter = false;
      if (col.name === undefined || col.filtring === false) sort = false;

      return {
        title: col.title,
        name: col.name,
        rowspan: col.rowspan === undefined ? 1 : col.rowspan,
        colspan: col.colspan === undefined ? 1 : col.colspan,
        row: col.row === undefined ? 0 : col.row,
        filtring: filter,
        sorting: sort,
        classname: col.classname === undefined ? "" : col.classname,
        prefix: col.prefix === undefined ? "" : col.prefix,
        dataOption: col.dataOption,
        button: col.button === undefined ? false : col.button,
        action: col.action,
        multipleSelect : this.props.onGetSelectedRows ===undefined?false :true, 
        dataType: getDataType(data, col.name),
      };
    });
    return formatedColumns;
  }
  
  checkData(col) {
    if (col.title === undefined) {
      throw new Error("Gridux properties < title > required");
    }
    if (col.title === "") {
      throw new Error("Gridux properties < title > should not be empty");
    }
  }

  async dataSotring(columnsName, direction) {
    var sortedData = await dataSortTool(
      this.state.data,
      columnsName,
      direction
    );
    this.setState({ data: await sortedData });
  }

  dataFilter(filterRepository) {
    var filtredData = dataFilterTool(this.props.data, filterRepository);
    this.setState({ data: filtredData });
  }
  onRowSelectedEventHandler(newRow){
   
    var selectedRows= [...this.state.selectedRows];
    var rowExist = selectedRows.some((row)=>{
      return JSON.stringify(row)===JSON.stringify(newRow)
    })
    if(rowExist){
      var RemovedIndex = selectedRows.map((row,index)=>{
          if(JSON.stringify(row)===JSON.stringify(newRow)){
            return index
          }
      }).filter((r)=>{
        return r!==undefined
      })[0]
      selectedRows.splice(RemovedIndex,1);
    }
    else{
      selectedRows.push(newRow)
    }
    this.setState({selectedRows:selectedRows},()=>{
      if( this.props.onRowsSelected!==undefined){
        this.props.onRowsSelected(this.state.selectedRows)
      }
    })
    return selectedRows
  }

  getHeaders(cols) {
    if (cols !== null && this.props.data.length > 0) {
      return <Headers columns={cols} onSort={this.dataSotring} selection={ this.props.onRowsSelected!==undefined}/>;
    }
  }

  getGridFilter(cols) {
    if (cols !== null && this.props.data.length > 0) {
      if (
        cols.some((col) => {
          return col.filtring === true;
        })
      ) {
        return <GridFilter columns={cols} OnFilterHandler={this.dataFilter} selection={ this.props.onRowsSelected!==undefined} />;
      }
    }
  }



  getData(cols) {
    if (this.props.data.length > 0 && cols !== null) {
      return <GridData columns={cols} data={this.state.data} onRowSelected={this.onRowSelectedEventHandler} selection={ this.props.onRowsSelected!==undefined} />;
    }
  }

  render() {
    var cols = this.setDefaultValuesToProps(
      this.props.columns,
      this.props.data
    );
    return (
      <div id="gridux">
        {/*Static rows*/}
        <table>
          <thead>
            {this.getHeaders(cols)}
            {this.getGridFilter(cols)}
          </thead>

          {this.getData(cols)}
        </table>
      </div>
    );
  }
}
