export async function dataSortTool(data, colName, direction) {
  var firstElement = objectDeepFind(data[0], colName);
  var dataType = typeof firstElement;
  switch (dataType) {
    case "number":
      return await data.sort(function (a, b) {
        var firstValue = objectDeepFind(a, colName);
        var secondValue = objectDeepFind(b, colName);
        switch (direction) {
          case "ascending":
            return firstValue - secondValue;
          case "descending":
            return secondValue - firstValue;
          default:
            return 0;
        }
      });
    case "string":
      return await data.sort((a, b) => {
        var firstValue = objectDeepFind(a, colName).toString();
        var secondValue = objectDeepFind(b, colName).toString();
        switch (direction) {
          case "ascending":
            if (firstValue < secondValue) return -1;
            else if (firstValue > secondValue) return 1;
            break;
          case "descending":
            if (firstValue > secondValue) return -1;
            else if (firstValue < secondValue) return 1;
            break;
          default:
            return 0;
        }
        return 0;
      });
    default:
      return data;
  }
}

export function dataFilterTool(Data, filterRepository) {
 
  
  for (let index = 0; index < filterRepository.length; index++) {
    Data = Data.filter((row) => {
      var value = objectDeepFind(
        row,
        filterRepository[index].colName
      )
      if(value ===undefined){
        value =""
      }
      else 
      value = value.toString();

      if (filterRepository[index].flag === 1)
        return value === filterRepository[index].colValue;
      if (filterRepository[index].flag === 2) {
        return compareDate(
          new Date(formateMicrosoftJsonDate(value)),
          new Date(filterRepository[index].colValue)
        );
      }

      return value.startsWith(filterRepository[index].colValue);
    });
  }
  return Data;
}

function compareDate(fDate, sDate) {
  fDate = new Date(
    fDate.getFullYear() +
      "." +
      (fDate.getMonth() + 1).toString() +
      "." +
      fDate.getDate()
  );
  sDate = new Date(
    sDate.getFullYear() +
      "." +
      (sDate.getMonth() + 1).toString() +
      "." +
      sDate.getDate()
  );
  var sf1 =
    fDate.getFullYear() +
    "." +
    (fDate.getMonth() + 1).toString() +
    "." +
    fDate.getDate();
  var sf2 =
    sDate.getFullYear() +
    "." +
    (sDate.getMonth() + 1).toString() +
    "." +
    sDate.getDate();
  return sf1 === sf2;
}

export function arrayRemoveByAttr(arr, attr, value) {
  var i = arr.length;
  while (i--) {
    if (
      arr[i] &&
      arr[i].hasOwnProperty(attr) &&
      arguments.length > 2 &&
      arr[i][attr] === value
    ) {
      arr.splice(i, 1);
    }
  }
  return arr;
}

export function objectDeepFind(obj, path) {
  var paths = path.split("."),
    current = obj,
    i;
  for (i = 0; i < paths.length; ++i) {
    if (current[paths[i]] === undefined) {
      return;
    } else {
      current = current[paths[i]];
    }
  }
  return current;
}

export function getDataType(data, colName) {
  try {
    if (data !== undefined && data.length > 0) {
      if (colName !== undefined) {
        var firstElement = objectDeepFind(data[0], colName);
        var initType = getDatTypeForElemet(firstElement);

        for (let index = 0; index < data.length; index++) {
          var value = objectDeepFind(data[index], colName);
          var currType = getDatTypeForElemet(value);
          if (currType !== initType) return "string";
        }
        return initType;
      }
    }
  } catch (error) {
    console.log(error + " of " + colName);
  }
}

function getDatTypeForElemet(value) {
  if (itMicrosoftDate(value)) return "date"; //Check if microsoft date
  return typeof value;
}

function itMicrosoftDate(value) {
  var size = value.length;
  return (
    value.toString().substring(0, 6) === "/Date(" &&
    value.substring(size - 2, size) === ")/"
  );
}

//Formate microsoft json date format to javascript date format /Date(1224043200000)/
export function formateMicrosoftJsonDate(date) {
  var primarry = new Date(parseInt(date.toString().slice(6).slice(0, -2)));
  primarry =
    primarry.getFullYear() +
    "." +
    (primarry.getMonth() + 1).toString() +
    "." +
    primarry.getDate();
  return primarry;
}

export function setToGermanDateFormat(bruteDate) {
  var date = new Date(Date.parse(bruteDate));
  var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
  var month =
    date.getMonth() < 9
      ? "0" + (date.getMonth() + 1).toString()
      : (date.getMonth() + 1).toString();
  var formatedDate = day + "." + month + "." + date.getFullYear();
  return formatedDate;
}
