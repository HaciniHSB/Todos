export default  function getData(){
    return[{
        firstName : "Souleyman",
        lastName : "Hacini",
        birthDay : "/Date(1224043200000)/",
        size : 175,
        details : {
            eysColor : "brown",
            preferedColor : "Black",
        }

    },{
        firstName: "ABCDEHIJKL",
        lastName: "ABCDEFGH",
        birthDay:  "/Date(1224043200000)/",
        size: 160,
        details: {
          eysColor: "ABVWX",
          preferedColor: "ABCDKLMN"
        }
      },{
        firstName: "ABCDKLMNO",
        lastName: "ABCFG",
        birthDay: "/Date(1224043200000)/",
        size: 965,
        details: {
          eysColor: "ABCDJK",
          preferedColor: "AQRSTUVW"
        }
      },
      {
        firstName: "ABCPQ",
        lastName: "ABCUVWX",
        birthDay: "/Date(1224043200000)/",
        size: 472,
        details: {
          eysColor: "WXYZABC",
          preferedColor: "IJKLMN"
        }
      },
      {
        firstName: "JKLM",
        lastName: "ABCDEPQRS",
        birthDay: "/Date(1224043200000)/",
        size: 444,
        details: {
          eysColor: "XYZABC",
          preferedColor: "ABCDEF"
        }
      },
      {
        firstName: "V",
        lastName: "ABCMNO",
        birthDay: "/Date(1224043200000)/",
        size: 639,
        details: {
          eysColor: "ABHI",
          preferedColor: "DEFG"
        }
      }

]
}