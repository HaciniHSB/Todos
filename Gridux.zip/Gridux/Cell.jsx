import React from "react"
import { objectDeepFind,formateMicrosoftJsonDate,setToGermanDateFormat } from "./Tools";
export  class Cell extends React.Component{


    render(){
        var classnaming = this.props.col.name !== undefined ? this.props.col.name.toLowerCase() : "";
    
        if (this.props.col.classname !== undefined)
        classnaming = classnaming + " " + this.props.col.classname;
    
     
        if (this.props.col.button === false) {
        var value = objectDeepFind(this.props.row, this.props.col.name);
    
      
        if (this.props.col.dataType === "date")
          value = setToGermanDateFormat(formateMicrosoftJsonDate(value));


        else if (this.props.col.dataOption !== undefined) {
          try {
            var option = this.props.col.dataOption.filter((opt) => {
              return opt.originalValue === value;
            });
            if (option.length > 0) {
              value =
                option[0].shownValue.slice(-1) === ";"
                  ? String.fromCharCode(option[0].shownValue.slice(0, -1))
                  : option[0].shownValue;
              var specialClasse =
                option[0].classname !== undefined ? option[0].classname : "";
              classnaming = classnaming + " " + specialClasse;
            }
          } catch (error) {
            console.log(option);
          }
        }
    
        
        return (
          <td className={classnaming}>
            {value} {this.props.col.prefix}
          </td>
        );
      }
    
      return (
        <td className={classnaming}>
          <button
            onClick={() => {
              this.props.col.action(this.props.row);
            }}
            type="button" data-toggle="modal" data-target="#exampleModalCenter"
          >
            Provis
          </button>
        </td>
      );
    }
}
export default Cell;
