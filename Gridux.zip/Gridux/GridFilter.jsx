import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBroom } from "@fortawesome/free-solid-svg-icons";
export default class GridFilter extends React.Component {
  constructor(props) {
    super();
    this.state = {
      filterRepository: [],
      filters: [],
      filterExist: "inline",
    };
    this.getFilter = this.getFilter.bind(this);
    this.OnFilterHandler = this.OnFilterHandler.bind(this);
    this.updateFilterRepository = this.updateFilterRepository.bind(this);
    this.setFilter = this.setFilter.bind(this);
  }

  getOptions(col) {
    return col.dataOption.map((opt, index) => {
      var value = opt.shownValue.slice(-1) === ";"
          ? String.fromCharCode(opt.shownValue.slice(0, -1))
          : opt.shownValue;

      return (
        <option key={index} value={opt.originalValue} className={opt.classname}>
          {value}
        </option>
      );
    });
  }

  getSelector(col, index) {
    return (
      <td className={col.name.toLowerCase() + " " + col.classname} key={index}>
        <select name={col.name} onChange={this.OnFilterHandler}>
          <option value="All">Alles</option>
          {this.getOptions(col)}
        </select>
      </td>
    );
  }
  getFilter() {
    return this.props.columns.map((col, index) => {
      if (col.colspan > 1) return null;
      if (col.filtring === false)
        return <td className={col.classname} key={index}></td>;

      if (col.dataOption !== undefined) {
        return this.getSelector(col, index);
      }
      switch (col.dataType) {
        case "number":
          return (
            <td
              className={col.name.toLowerCase() + " " + col.classname}
              key={index}
            >
              <input
                type="number"
                name={col.name}
                onChange={this.OnFilterHandler}
              />
            </td>
          );
        case "date":
          return (
            <td
              className={col.name.toLowerCase() + " " + col.classname}
              key={index}
            >
              <input
                type="date"
                name={col.name}
                onChange={this.OnFilterHandler}
                id="dt"
              />
            </td>
          );
        default:
          return (
            <td
              className={col.name.toLowerCase() + " " + col.classname}
              key={index}
            >
              <input
                type="text"
                name={col.name}
                onChange={this.OnFilterHandler}
              />
            </td>
          );
      }
    });
  }
  OnFilterHandler(e) {
    var filtredRedpo = this.updateFilterRepository(e);
    this.setState({ filterRepository: filtredRedpo }, () => {
      this.props.OnFilterHandler(this.state.filterRepository);
    });
  }

  updateFilterRepository(e) {
    var colName = e.target.getAttribute("name");
    var colValue = e.target.value;
    var flag = e.target.type === "select-one" ? 1 : 0;
    flag = e.target.type === "date" ? 2 : flag;
    var currentRepo = this.state.filterRepository.slice();
    var keyExist = currentRepo.some((col) => col.colName === colName);
    if (keyExist) {
      if (
        colValue.length === 0 ||
        (colValue === "All") | (colValue === "NaN.NaN.NaN")
      ) {
        var removeIndex = currentRepo
          .map(function (item) {
            return item.colName;
          })
          .indexOf(colName);
        currentRepo.splice(removeIndex, 1);
      } else {
        currentRepo = currentRepo.map((item) => {
          if (item.colName === colName) {
            item.colValue = colValue;
          }
          return item;
        });
      }
    } else {
      if (colValue.length !== 0) {
        currentRepo.push({ colName: colName, colValue: colValue, flag: flag });
      }
    }
    return currentRepo;
  }

  setFilter() {
    this.setState({ filterRepository: [] }, () => {
      this.props.OnFilterHandler(this.state.filterRepository);
    });

    this.setState({ filters: [] }, () => {
      var inputs = this.getFilter();
      this.setState({ filters: inputs });
    });
  }

  componentDidMount() {
    var inputs = this.getFilter();
    this.setState({ filters: inputs });
  }

  render() {
    function SelectionTd(props){
      if(props.selection)
      return <td className="fselect"></td>
      return null
    }

    return (
      <tr id="filter">
        <SelectionTd selection = {this.props.selection}/>
        <td className="idnumber cleaner sharp" id="resetFilter">
          <FontAwesomeIcon
            icon={faBroom}
            title="Filter zurücksetzen"
            onClick={this.setFilter}
          />
        </td>
        {this.state.filters}
      </tr>
    );
  }
}
