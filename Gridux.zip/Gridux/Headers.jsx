import React from "react";
import Header from "./Header";

export default class Headers extends React.Component {
  constructor(props) {
    super();
    this.state = {
      name: null,
      direction: null,
    };
    this.getHeaders = this.getHeaders.bind(this);
    this.setDirection = this.setDirection.bind(this);
    this.getdirection = this.getdirection.bind(this);
  }

  setDirection(name, direction) {
    this.setState({ name: name, direction: direction });
  }

  getdirection(name) {
    if (this.state.name === name) return this.state.direction;
    return "default";
  }

  putSharpHeader(indec) {}

  getHeaders() {
    const rows = [];
    const rowsValues = this.props.columns.map((col) => {
      return col.row;
    });
    const rowSpanValues = this.props.columns.map((col) => {
      return col.rowspan;
    });
    const rowsCount = Math.max(...rowsValues);
    const maxRowSpan = Math.max(...rowSpanValues);
    const sharpColumn = <th className="sharp" rowSpan={maxRowSpan}>#</th>;
    function SharpColumn(props) {
      if(props.index===0)
      return  sharpColumn
      return null
    }
    function SelectionTd(props){
      if(props.selection)
      return <td className="hselect"></td>
      return null
    }
    for (let nb = 0; nb <= rowsCount; nb++) {
      var classenaming ="headers "+"header_"+nb
      rows.push(
        <tr className={classenaming} key={nb}>
           <SelectionTd selection = {this.props.selection}/>
            <SharpColumn index={nb} />
          {this.props.columns
            .filter((col) => {
              return col.row === nb;
            })
            .map((col, index) => {
              return (
                  <Header
                    key={index}
                    rowspan={col.rowspan}
                    colspan={col.colspan}
                    name={col.name}
                    title={col.title}
                    onSort={this.props.onSort}
                    dataType={col.dataType}
                    classname={col.classname}
                    dataOption={col.dataOption}
                    sorting={col.sorting}
                    sortingDirection={this.getdirection(col.name)}
                    setDirection={this.setDirection}
                  />
              );
            })}
        </tr>
      );
    }

    return rows;
  }

  render() {
    return <React.Fragment>{this.getHeaders()}</React.Fragment>;
  }
}
